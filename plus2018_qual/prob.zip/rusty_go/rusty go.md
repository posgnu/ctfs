문제이름: rusty go

설명: So rusty!

난이도: easy

분야: pwn, reversing