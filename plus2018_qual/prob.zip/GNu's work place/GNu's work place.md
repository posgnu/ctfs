문제이름: GNu's work place

설명:  I try to book a meeting room with fastfive application. But I can only book for up to 2 hours, as you see. I want to book the room more than that. But I do not know what to do. So I want you to do it. As a first step, we have to find the routine cheking what time we try to book. So, The flag is `the signature of admin user level` + `maximum time length that admin can book`

you have to submit the flag in form of PLUS{md5(flag)}.

I will give you a screenshot that shows that the reservation was declined.



**Very important**

> Do static analysis! Don't try to send any illegal packet to server, for example, log-in as illegal guest bypassing log-in routine.  You can really be sued!^^; 



flag =  PLUS{63029d9448801707266571326ce202ce}



난이도: hard

분야: reversing