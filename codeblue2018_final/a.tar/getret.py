f = open('dump', 'r')
rets = []
index = 0

def check(m, n):
    c = m - n
    if c in [1,2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072, 262144, 524288, 1048576]:
        return c
    else:
        return 0

slad = []
while True:
    tmp = f.read(1) 
    if index > 0x1c0000:
        break
    if tmp == '':
        break

    if ord(tmp) == 0x90 or ord(tmp) == 0x00:
        slad.append(hex(index))
    elif ord(tmp) == 0xc3:
        rets.append(index)
        slad.append(hex(index))
        print "".join(slad)
        slad = []
    else:
        slad = []
    index += 1

jumpret = []
for i in range(len(rets)- 19):
    bita = ''
    fl = False
    for j in range(1,20):
        tmp = check(rets[i + j], rets[i])
        if tmp != 0:
            bita += str(tmp) + ' '
            fl = True
        else:
            bita += ' '
    if fl:
        jumpret.append(hex(rets[i]) + ': ' + bita)

